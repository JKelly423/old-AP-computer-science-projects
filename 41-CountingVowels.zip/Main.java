import static java.lang.System.out;
import java.util.Scanner;

class Main {
  public static void main(String[] args) {
    Scanner kb = new Scanner(System.in);
		System.out.print("Enter the word: ");
		String s = kb.next();
		/*declare and initialize a variable for total*/
		
		int total = 0;
		
		for(int i = 0 ; i < s.length(); i++)
		{
			String let = s.substring(i,(i+1));
			String vowels = "aeiou";
			if( vowels.indexOf(let) > -1)
			{
			  System.out.print(let + " ");
			  total++;
			  
			}
		}
		System.out.println();
		System.out.print("Total vowels = " + total);
  }
}