#include <iostream>
#include <iomanip>
using namespace std; 

struct student {
	string name;
	double gpa;
	bool honorRoll;
	};
	
void printStudent(student);

int main() {
	cout << setprecision(2) << fixed;
  student boy;
  student girl;
  student random;
  
	boy.name = "jeff";
	boy.gpa = 3.75;
	boy.honorRoll = true;
	
	girl.name = "emily";
	girl.gpa = 3.93;
	girl.honorRoll = true;
	
	random.name = "aidan";
	random.gpa = 2.34;
	random.honorRoll = false;
	
	student myClass[3] = {boy, girl, random};
	
	student highestGrade;
	highestGrade.gpa = 0.0;

	for (int i=0; i < 3; i++){
		if ( myClass[i].gpa > highestGrade.gpa ){
			highestGrade = myClass[i];
		}
	}
	
  cout << highestGrade.name << " has the highest GPA: " << highestGrade.gpa;
}

void printStudent(student s){
	cout << setprecision(2) << fixed;
	cout << "\nName: " << s.name;
	cout << "\nGPA: " << s.gpa;
	cout << "\nHonor Roll: " << s.honorRoll;
}
