#include <iostream>
#include <cstdlib>
#include <fstream>
using namespace std;

string encrypt(int);
void decrypt(string);

int main() {


string hash = encrypt(50);
cout << hash << endl;
ofstream hashFile;
hashFile.open("hash.txt");
hashFile << "Hash: " << hash;
hashFile.close();
cout << "Decrypt: " << endl;
decrypt(hash);

}

string encrypt(int s){
cout << "Enter phrase to encrypt: ";
string str;
getline(cin,str);
string ready = "";

for (int i=str.length()-1; i > -1; i--){
  ready += str[i];
}

ready = "sAlT" + ready + "SaLt";
string encrypted = "";
int num = rand() % 130 + 120 ;

for (int i=0;i<ready.length();i++) { 
  if (ready[i] == ' '){
    encrypted += " ";
  }
  else{
    encrypted += char(int(ready[i]) +num); 
  }
}
  return encrypted; 
} 

void decrypt(string s){




string decrypted = "";
int shift = 0;
ofstream file;
file.open("log.txt");
while (shift <= 256 ){

decrypted = "";
	
  for( int i=0; i < s.length(); i++ ){
  	
	
	
   if (s[i] == ' '){
     cout <<" ";
		 decrypted += " ";
   }
   else{
     cout <<  char(int(s[i]) - shift);
     decrypted +=  char(int(s[i]) - shift) ;
   }
  
}
cout << endl << "decrypted after first loop: " << decrypted << endl << endl;
file << "decrypted after first loop: " << decrypted << endl << endl;
shift++;
}



}

