#include <iostream>
#include <stdlib.h>
using namespace std;


struct Card
{
  int value;
  string suit ;
  string faceName;
} ;


struct Player
{
  string nameOfPlayer;
  Card playerHand[5]; // each player can recieve a maxiumum of 5 hands per round
  
};


void dealHands();
void shuffleDeck(Card[]);
void showCard(Card);

Card deck[52];
Player bot;
Player user;
int deckPos = 0;
int hand = 0;

int main() {
  

   int values[13] = {2,3,4,5,6,7,8,9,10,10,10,10,1};
   string suits[4] = {"\u2662", "\u2661", "\u2667", "\u2664"};
		//                diamonds    hearts    clubs     spades
   for (int i=0; i < 13; i++){
   	string fn = "";
   	
   	switch(i){
   		case 0: fn = "Two"; break;
   		case 1: fn = "Three"; break;
   		case 2: fn = "Four"; break;
   		case 3: fn = "Five"; break;
   		case 4: fn = "Six"; break;
   		case 5: fn = "Seven"; break;
   		case 6: fn = "Eight"; break;
   		case 7: fn = "Nine"; break;
   		case 8: fn = "Ten"; break;
   		case 9: fn = "Jack"; break;
   		case 10: fn = "Queen"; break; 
   		case 11: fn = "King"; break;
   		case 12: fn = "Ace"; break;
   		default: fn = "Error";
   	}
		
   	for (int x=0; x < 4; x++){
   		Card c;
   		c.value = values[i];
   		c.suit = suits[x];
   		c.faceName = fn;
   		deck[deckPos] = c;
   		deckPos++;
   	}
   	
   }
   
  

   
   

	
	
		for (int i=0; i < 52; i++){ // prints out deck
			showCard(deck[i]);
	}
	
	 deckPos = 51;
	 hand = 0;

	dealHands();
	// done with initilizaiton, deck is made, each hand is delt.
 
}

void dealHands(){
	
	
	hand++;
}

void showCard(Card c){
	cout << c.faceName << " " << c.suit << "  (value:" << c.value << ")" << endl;
}

void shuffleDeck( Card deck[52] ){

	for (int i=0; i < 52; i++){ //shuffle the deck. swap each card in the deck with a random card from the deck.
		Card temp;
		int num = rand() % 52;
		temp = deck[i];
		deck[i] = deck[num];
		deck[num] = temp;
	}

}


  