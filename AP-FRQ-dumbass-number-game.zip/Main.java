import java.util.*;

class Main {
  public static void main(String[] args) {
    
		Scanner kb = new Scanner(System.in);
		int rounds = 5;
		int round = 1;

		int userTotal = 10;
		int botTotal = 10;
	do {

		System.out.println("Round " + round);
		System.out.println("=========");
		System.out.println("Player 1: " + userTotal);
		System.out.println("Player 2: " + botTotal);

		System.out.print("\nHow many coins do you want to spend? (1-3): ");
		int userRound;
		userRound = kb.nextInt();
		userTotal -= userRound;

		int botRound = round;
		botTotal -= botRound;
		
		System.out.println("Player 2 has played " + botRound + " coins!");

		int diff = userRound - botRound;
		if (diff < 0){
			diff *= -1;
		}

		switch(diff){
			case 0: System.out.println("player 2 gains 1\n"); botTotal += 1; break;
			case 1: System.out.println("player 2 gains 1\n"); botTotal += 1; break;
			case 2: System.out.println("player 1 gains 2\n"); userTotal += 2; break;
		}

	round++;
	} while ( round <= rounds && userTotal > 3 && botTotal > 3 );

	System.out.println("\n\nFINAL SCORE");
	System.out.println("===========");
	System.out.println("\nPlayer 1: " + userTotal);
	System.out.println("Player 2: " + botTotal);

	if (userTotal > botTotal){
		System.out.print("PLAYER 1 WINS!");
	} else if ( userTotal < botTotal ){
		System.out.print("PLAYER 2 WINS!");
	} else{
		System.out.print("IT'S A TIE! We hate winners! Just like soccer!");
	}

  }
}