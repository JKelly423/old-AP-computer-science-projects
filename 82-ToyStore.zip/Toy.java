import java.util.*;

public class Toy
{
	private String name;// name of the toy
	private int count;// how many toys exist at the store
	private double cost;// cost of one toy
	private boolean isOnSale; // 

	public Toy(String name, double cost, int count, boolean isOnSale)// default, do we really want a default constructor ??
	{
		this.name = name;
		this.cost = cost;
		this.count = count;
		this.isOnSale = isOnSale;
	}

	public Toy( String nm )// what default values do we put in for the other 2 instance variables ??
	{
		
	}
	
	public void setSale(){
		if (isOnSale == false){
			isOnSale = true;
			cost = cost * 0.75;
		}
	}
	
	public void removeSale(){
		if (isOnSale == true){
			isOnSale = false;
			cost = (cost * 100)/75; // algorithm that calculates 100% price given that current price is 75% normal price (25% discount)
		}
	}
	
	public int getQuantity()
	{
		return count;
	}
	
	public void setQuantity( int cnt )
	{
		count = cnt;
	}
	
	public String getName()
	{
		return name;
	}
	
	public void setName( String nm )
	{
		name = nm;
	}

	public String toString()
	{
	   return "Name: " + name + " | Cost: $" + cost + " | Stock: " + count + " | On Sale?: " + isOnSale;
	}
}