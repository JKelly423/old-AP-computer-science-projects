import java.util.*;


public class ToyStore
{
	private ArrayList<Toy> toyList;


	public ToyStore()
	{
	  //1. create the arrayList 
	  
	  toyList = new ArrayList<Toy>();
	}

	public void addAToy( String toyName,  double costOfToy, int quantityAvailable)
	{
		Toy t = new Toy(toyName,costOfToy, quantityAvailable, false);
		
		toyList.add(t);
		
	}
  
  
  public void addAToy( Toy t )
	{
		toyList.add(t);
	}
  	
  	
  	public Toy getThatToy( String nm )
  	{
  	  //loo thru the list and return the entire Toy object
  	  for (Toy t : toyList){
  	  	if (t.getName().equals(nm)){
  	  		return t;
  	  	}
  	  }
  		return null;
  	}
  
  	public String getMostFrequentToy()// the toy that the store has the most of 
  	{
  		Toy stocked = new Toy("",0.00,0, false);
  		
  		for (Toy t : toyList){
  			if (t.getQuantity() >= stocked.getQuantity()){
  				stocked = t;
  			}
  		}
  		return stocked.getName();
  	}  
  
  
  // put the mostFrequentToy on sale (the sale is alwys 25% off )
  	public void  putMostFrequentOnSale()// change the price 
  	{
  	  getThatToy( getMostFrequentToy() ).setSale();
  	}  
  	
  	
  	
  	// put all Toys on sale (the sale is alwys 25% off )
  	public void  putAllToysOnSale()
  	{
  		for (Toy t : toyList){
  			t.setSale();
  		}
  	}  
  	
   public boolean sellToy(String name )
  	{

  		Toy t = getThatToy(name);
  		
  		if (t != null && t.getQuantity() > 0){
  			t.setQuantity( t.getQuantity() - 1);
  			if (t.getQuantity() <= 0){
  				toyList.remove(t);
  			}
  			return true;
  		}
  		
  		System.out.println("Sorry, but we are currently out of stock on that item!");
  		return false;
  	}  
  	  
	public String toString()
	{
	   return Arrays.toString(toyList.toArray());
	}
}