import java.util.*;

public class Main
{
	public static void main( String args[] )
	{
	
		ToyStore toysRUs = new ToyStore();
		
		Toy ninja = new Toy("Ninja", 20.00, 10, false);
		Toy soldier = new Toy("Captain", 15.00, 5, false);
		Toy raceCar = new Toy("Race Car", 10.00, 5, false);
		
		toysRUs.addAToy(ninja);
		toysRUs.addAToy(soldier);
		toysRUs.addAToy(raceCar);
		toysRUs.addAToy("Moose", 5.00, 3);
		
		System.out.println(toysRUs);
		System.out.println();
		
		 toysRUs.sellToy("Ninja");
		 
		 // System.out.println("Most Frequent Toy: " + toysRUs.getMostFrequentToy());
		// toysRUs.putMostFrequentOnSale();
		
		toysRUs.putAllToysOnSale();
		toysRUs.getThatToy("Ninja").removeSale();
		System.out.println(toysRUs);
	}
}