import java.util.Scanner;

class Main {
  
  public static void main(String[] args) {
    
    Scanner kb = new Scanner(System.in);
    
    System.out.print("Enter a word: ");
    String word = kb.nextLine();
    
    boolean palindrome = isPalindrome(word);
    
    if ( palindrome ){
      System.out.print(word + " is a palindrome.");
    }
    else {
      System.out.print(word + " is not a palindrome.");
    }
    
  }
  
  
    
  public static boolean isPalindrome( String word )
  {
    
		
		if (word.substring(word.length() - 1).compareTo(word.substring(0,1)) == 0 && word.substring(word.length() - 2, word.length() - 1 ).compareTo(word.substring(1,2)) == 0 )
		{
      return true ; 
		}
		
		else {
		  return false;
		}
  }
  
  
}