import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;

class Main {
  public static void main(String[] args) {
    
    
    
  System.out.println( maxLength(  Arrays.asList("mary", "Danny", "penny", "MaryKathleen", "Angeline") )  );
 
 
  List <String> myFriends = new ArrayList<String>();
 myFriends.add("mary");
 myFriends.add("danny");
 myFriends.add("sue");
 myFriends.add("leah");
 myFriends.add("mary");
 myFriends.add("mary");
 
  
  removeDuplicates( myFriends );
  markLength4( myFriends );
  removeEvenLength ( myFriends  ); // ------------
  System.out.println("maxLength: " + maxLength(myFriends) );
  System.out.println("removeEvenLength: " + myFriends);
  
 
  }
  
  // returns the integer that represents the nmber of characters that the longest String has 
  public static int maxLength( List<String> list) {
  	int max = -99999;
  	
  	for (String s : list){
  		if (s.length() > max)
  			max = s.length();
  	}
  	
  	if (max < 0)
  		max = 0;
  	
    return max ;
  }
  
  // removes all strings that are even length 
  public static void removeEvenLength(List<String> list) {
    
    ArrayList<String> remove = new ArrayList<String>(); // had to make to avoid a concurrent modificiation exception
    
    for (String s : list){
    	if (s.length() % 2 == 0)
    		remove.add(s);
    }
    
    for (String s : remove){
    	list.remove(s);
    }
    
  }
  
  
  // removes any string that is in the list twice
  //( nested loop needed and if you remove one decrement i, to look at next one )
  public static void removeDuplicates(List<String> list) {
  	
  	ArrayList<String> remove = new ArrayList<String>(); // needed to avoid concurrent modificiation exception
  	
  	for (int i=0; i < list.size(); i++){
  		if ( search( list, list.get(i), (i+1) ) )
  			remove.add(list.get(i));
  	}
  		
  	for (String s : remove){
  		list.remove(s);
  	}
  }
  

  
  
  
  // this method changes all the strings that are of length 4 to have an * in front of the name 
  public static void markLength4(List<String> list) {
  	
  	for( int i=0; i < list.size(); i++){
  		
  		if ( (list.get(i)).length() == 4 )
  			list.set(i, ("*" + list.get(i)) );
  			
  	}
  	
  }
 
 
	 // I just wrote a search method since I used them so often
	 
  public static boolean search (List<String> list, String word){
  	
  	for (String s : list){
  		if ( s.equals(word) )
  			return true;
  	}
  	
  	return false;
  }
  
    public static boolean search (List<String> list, String word, int start){
  	
  	for (int i=start; i < list.size(); i++){
  		if ( (list.get(i)).equals(word) )
  			return true;
  	}
  	
  	return false;
  }
  
  
}