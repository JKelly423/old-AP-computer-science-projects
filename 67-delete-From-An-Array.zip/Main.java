//array delete example
public class Main
{
	public static void main(String[] args)
	{
		int[] nums = {7,3,3,7,1,8,7,8,7,4,3,7, 9,8,3};
		printIt( nums ); // calling the method to print the array 

		System.out.println("\nthere are " + countIt( nums, 7 ) + " 7's in the array "  );
		//System.out.println("\ncount of 8s = " + countIt( nums, 8 ) );

		nums = deleteIt( nums, 7 ) ;// deleting all the 7's
		printIt( nums ); // calling the method to print the array 
	}



	/* * countIt should return a count that represents how many times val exists in the array iRay */
	public static int countIt( int[] iRay, int val )
	{
		int count =0;
		for (int x : iRay){
		  if (x == val){
		    count++;
		  }
		}
      return count;
	}

/* deleteIt should return an array without the vals  that are in the array iRay	 */
	public static int[ ] deleteIt( int[ ] iRay, int val )
	{
		int count = countIt(iRay,val);
		
		int[] arr = new int[iRay.length - count];
		
		int index = 0;
		
		for (int z : iRay){
		  
		  if (z != val){
		    arr[index] = z;
		    index++;
		  }
		  
		}
		
		return arr;
	}
	
	
	public static void printIt( int[ ] iRay  )
	{               
	  
	    System.out.print("[ ");
	  
		  for(int z=0; z < iRay.length; z++)
      {	
        
        if ( z < iRay.length - 1 ){
          System.out.print(iRay[z] + ", ");    
        } 
        else {
          System.out.print(iRay[z] + " ");
        }
      }
      
       System.out.print("] ");
	}    
	
  
  
}// end of class --------------
