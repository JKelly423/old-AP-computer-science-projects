import static java.lang.System.out;
import java.util.Scanner;

class Main {
  public static void main(String[] args) {
    Scanner kb = new Scanner(System.in);
		System.out.print("Enter a positive or negative number or 0 to quit: ");
		int num = kb.nextInt();
	
	  int posCount = 0;
	  int negCount = 0;
	
	  while (num != 0){
	    
	    if (num > 0){
	      posCount++;
	    }
	    else if (num < 0){
	      negCount++;
	    }
		  System.out.print("Enter a positive or negative number or 0 to quit: ");
		  num = kb.nextInt();
	  }
		
		
		System.out.println("There were " + posCount + " positive numbers and " + negCount + " negative numbers.");
  }
}