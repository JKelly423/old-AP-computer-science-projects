import java.util.Scanner;

class Main {
  public static void main(String[] args) {
    
    Scanner kb = new Scanner(System.in);
    
    int num;
    int smallest = (Integer.MAX_VALUE);
    int largest = (Integer.MIN_VALUE);
    
    for (int i = 1; i <= 5; i++){
      
      System.out.print("Number: ");
      num = kb.nextInt();
      
      if (num > largest){
        largest = num;
      }
      if (num < smallest){
        smallest = num;
      }
      
    }
    
    System.out.println("Max value is: " + largest);
    System.out.println("Min value is: " + smallest);
    
  }
}