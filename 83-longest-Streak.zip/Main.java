class Main {
  public static void main(String[] args)
  {
   
   
  }
  
	public static String longestStreak(String str){
		int longest = 0;
		int current = 0;
		char let = ' ';

		for(int i=0; i < str.length()-1; i++){

			if (str.charAt(i) == str.charAt(i+1)){
				current++;
			} else{
				current = 1;
			}

			if (current > longest){
				longest = current;
				let = str.charAt(i);
			}
		}

		return "" + let + " " + longest;

	}
  
  
}