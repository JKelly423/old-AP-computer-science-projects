import java.util.Scanner;

class Main {
  public static void main(String[] args) {
    
    Scanner kb = new Scanner(System.in);
    
    System.out.print("First Word: ");
    String first = kb.nextLine();
    
    System.out.print("Second word: ");
    String second = kb.nextLine();
    
    if ( ( first.compareTo(second) ) == 0 ){
      System.out.print(first + " and " + second + " are the same.");
    }
    else{
      
      int letterNum;
      int tracker;
      
      if ( first.length() > second.length() ){
         tracker = second.length();
      }
      else{
         tracker = first.length();
      }

        
        for (int i = 0; i < tracker; i++){
          int add = 1;
          if (i == (tracker-1)){
            add = 2;
          }
        
          if ( i==(tracker-1) || (first.substring(i,(i+1))).compareTo( (second.substring(i,(i+1))) ) != 0 ){
            
            letterNum = (i + add);
            System.out.print(first + " and " + second + " are not the same. They differ at letter number " + letterNum +".");
            i = tracker;
          }
        }
    }
    
  }
}