public class Digits
{
 
 
      // count up how many digits a number contains
    public  int digitCounter ( int number )
    {
        int digits = 0;
        
        while (number > 0){
          
          digits++;
          number = (number / 10);
          
        }
      
        return digits;
    }

    // sum all of a numbers digits
    public  int digitAdder ( int number )
    {
      
      int digit = 0;
      int total = 0;
      
      while ( number > 0 ){
        
        digit = (number % 10);
        total += digit;
        number = (number / 10);
      }
      
      return total;
    }
    
    // average all of a numbers digits
    public double digitAverage  ( int number )
    {  
      
      int digit = 0;
      int total = 0;
      int counter = 0;
      
      while ( number > 0 ){
        
        digit = (number % 10);
        total += digit;
        number = (number / 10);
        counter++;
        
      }
      
      total /= counter;
      
       return total;
    }
    
    //count all of a numbers even digits
    public int countEvens ( int number )
    {  
      
      int digit = 0;
      int counter = 0;
      
      while ( number > 0 ){
        
        digit = (number % 10);
        number = (number / 10);
        
        if ( digit % 2 == 0 ){
          counter++;
        }
        
      }
      
       return counter;
    }
    
    // count all of a numbers odd digits
    public int countOdds ( int number )
    {  
      
      int digit = 0;
      int counter = 0;
      
      while ( number > 0 ){
        
        digit = (number % 10);
        number = (number / 10);
        
        if ( digit % 2 != 0 ){
          counter++;
        }
        
      }
      
       return counter;
    }
    
    // Generate all of the divisors for any given number
    public String divisors ( int number )
    {
     String divisors="";
     
    for (int i = 1; i <= number; i++){
      
      if (number % i == 0){
        divisors = (divisors + ( Integer.toString(i) ) + " ");
      }
      
    }
     
     return divisors; 
      
    }
    


}// end of class