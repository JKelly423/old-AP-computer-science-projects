class Main {
  
  public static void main(String[] args) {
    
    System.out.println("Hello world!");
    
    // create an instance of the other class by using the default constructor 
  
    Digits digits = new Digits();
  
    // call all the methods 
    // needed to test the methods 
    
    System.out.println("DigitCounter with 123: " + digits.digitCounter(123) );
    
    System.out.println("Digit adder with 123: " + digits.digitAdder(123) ); 
    
    System.out.println("Digit Average with 123: " + digits.digitAverage(123) );
    
    System.out.println("Count Evens with 123: " + digits.countEvens(123) );
    
    System.out.println("Count Odds with 123: " + digits.countOdds(123) );
    
    System.out.println("Divisors of 500: " + digits.divisors (500) );

  }
  
}